﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Libreria.EN;

namespace Libreria.CAD
{
    public class ArticuloCAD
    {
        private const string s = "data source=.\\SQLEXPRESS;Integrated Security=SSPI;AttachDBFilename=|DataDirectory|\\Profoon.mdf;User Instance=true";
        SqlConnection c = new SqlConnection(s);

        public ArticuloCAD()
        {
        }

        public DataTable ListarArticulos()
        {
            
            
            SqlDataAdapter da = new SqlDataAdapter("select * from Articulos", c);
            DataTable tb = new DataTable();
            da.Fill(tb);
            

            return tb;
        }
    }
}
